<?php
 
namespace App\Http\Controllers;
 
use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Mail;
use Carbon\Carbon;
use Auth;
use Session;
 
class AdminController extends Controller
{
    public $title;
    public function __construct()
    {
        $this->title='';
    }

    public function index(Request $request)
    {
        $this->title = 'Dashboard';
        if (Auth::user()) {
            return view('admin.index',['title' => $this->title]);
        } else {
            return redirect('admin/login');
        }
    }

    public function login(Request $request)
    {
        $this->title = 'Login';
        if (!Auth::user()) {
            if ($request->all()) {
                $credentials = $request->only('email', 'password');
                if (Auth::attempt($credentials)) {
                    Session::put('success', 'You have Successfully loggedin');
                    return redirect('admin');
                } else {
                    Session::put('error', 'Oppes! You have entered invalid credentials');
                    return view('admin.login',['title' => $this->title]);
                }
            }

            return view('admin.login',['title' => $this->title]);
        } else {
            return redirect('admin');
        }
    }
    
    public function forgotpassword(Request $request)
    {
        if (!Auth::user()) {
            if ($request->all()) {
                $request_data = $request->all();
                $check_user = User::where('email', $request_data['email'])->first();
                $token = Str::random(64);
                if (!empty($check_user)) {
                    Mail::send('email.verify', ['token' => $token], function ($message) use ($request) {
                        $message->to("mohit.pk.06@gmail.com");
                        $message->subject('Reset Password Notification');
                    });
                    if (Mail::failures()) {
                        Session::put('error', 'Oppes! Something went wrong, Please try again.');
                        return view('admin.forgot');
                    }
                    DB::table('password_resets')->insert(
                        ['email' => $check_user->email, 'token' => $token, 'created_at' => Carbon::now()]
                    );
                    Session::put('success', 'We have e-mailed your password reset link!');
                    return view('admin.forgot');
                } else {
                    Session::put('error', 'Oppes! Your entered email is not exist');
                    return view('admin.forgot');
                }
            }
            return view('admin.forgot');
        } else {
            return redirect('/');
        }
    }

    public function resetpassword($token)
    {
        if (!Auth::user()) {
            $check_token = DB::table('password_resets')->where('token', $token)->first();
            if (!empty($check_token)) {
                return view('admin.reset',['user_detail' => $check_token]);
            } else {
                Session::put('error', 'Oppes! Your token is not valid');
                return redirect('forgot-password');
            }
        } else {
            return redirect('/');
        }
    }

    public function updatePassword(Request $request)
    {
        if (!Auth::user()) {
            if ($request->all()) {
                $request_data = $request->all();
                $user_id = $request_data['user_id'];
                $user_detail = User::where('id', $user_id)->first();
                $user_detail->password = Hash::make($request_data['password']);
                $user_detail->save();
                DB::table('password_resets')->where(['user_id' => $user_id])->delete();
                Session::put('success', 'Your password has been changed');
                return redirect('/');
            }
        } else {
            return redirect('/');
        }
    }

    public function logout()
    {
        Session::flush();
        Auth::logout();
        return redirect('login');
    }
}