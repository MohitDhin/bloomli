<!DOCTYPE html>

<html lang="en" class="light-style customizer-hide" dir="ltr" data-theme="theme-default" data-assets-path="<?php echo e(url('public')); ?>/assets/" data-template="vertical-menu-template">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0" />

    <title>Bloomli - <?= $title ?></title>

    <meta name="description" content="" />

    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="<?php echo e(url('public')); ?>/assets/img/favicon/favicon.ico" />

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link href="https://fonts.googleapis.com/css2?family=Public+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap" rel="stylesheet" />

    <!-- Icons -->
    <link rel="stylesheet" href="<?php echo e(url('public')); ?>/assets/vendor/fonts/boxicons.css" />
    <link rel="stylesheet" href="<?php echo e(url('public')); ?>/assets/vendor/fonts/fontawesome.css" />
    <link rel="stylesheet" href="<?php echo e(url('public')); ?>/assets/vendor/fonts/flag-icons.css" />

    <!-- Core CSS -->
    <link rel="stylesheet" href="<?php echo e(url('public')); ?>/assets/vendor/css/rtl/core.css" class="template-customizer-core-css" />
    <link rel="stylesheet" href="<?php echo e(url('public')); ?>/assets/vendor/css/rtl/theme-default.css" class="template-customizer-theme-css" />
    <link rel="stylesheet" href="<?php echo e(url('public')); ?>/assets/css/demo.css" />

    <!-- Vendors CSS -->
    <link rel="stylesheet" href="<?php echo e(url('public')); ?>/assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.css" />
    <link rel="stylesheet" href="<?php echo e(url('public')); ?>/assets/vendor/libs/typeahead-js/typeahead.css" />
    <link rel="stylesheet" href="<?php echo e(url('public')); ?>/assets/vendor/libs/toastr/toastr.css" />
    <link rel="stylesheet" href="<?php echo e(url('public')); ?>/assets/vendor/libs/animate-css/animate.css" />
    <!-- Vendor -->
    <link rel="stylesheet" href="<?php echo e(url('public')); ?>/assets/vendor/libs/formvalidation/dist/css/formValidation.min.css" />

    <!-- Page CSS -->
    <!-- Page -->
    <link rel="stylesheet" href="<?php echo e(url('public')); ?>/assets/vendor/css/pages/page-auth.css" />
    <!-- Helpers -->
    <script src="<?php echo e(url('public')); ?>/assets/vendor/js/helpers.js"></script>

    <!--! Template customizer & Theme config files MUST be included after core stylesheets and helpers.js in the <head> section -->
    <!--? Template customizer: To hide customizer set displayCustomizer value false in config.js.  -->
    <script src="<?php echo e(url('public')); ?>/assets/vendor/js/template-customizer.js"></script>
    <!--? Config:  Mandatory theme config file contain global vars & default theme options, Set your preferred theme option in this file.  -->
    <script src="<?php echo e(url('public')); ?>/assets/js/config.js"></script>

    <script src="<?php echo e(url('public')); ?>/assets/vendor/libs/jquery/jquery.js"></script>
    <style>
        .toast-placement-success {
            position: fixed;
        }
    </style>
</head>

<body>
    <!-- Content -->

    <?php echo $__env->yieldContent('content'); ?>
    <div class="bs-toast toast toast-placement-ex m-2" role="alert" aria-live="assertive" aria-atomic="true" data-bs-delay="2000">
        <div class="toast-header">
            <i class="bx bx-bell me-2"></i>
            <div class="me-auto fw-semibold">Error</div>
            <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
        </div>
        <div class="toast-body error_custom_body"></div>
    </div>
    <div class="bs-toast toast toast-placement-success m-2" role="alert" aria-live="assertive" aria-atomic="true" data-bs-delay="2000">
        <div class="toast-header">
            <i class="bx bx-bell me-2"></i>
            <div class="me-auto fw-semibold">Success</div>
            <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
        </div>
        <div class="toast-body success_custom_body"></div>
    </div>


    <!-- / Content -->

    <!-- Core JS -->
    <!-- build:js assets/vendor/js/core.js -->
    <script src="<?php echo e(url('public')); ?>/assets/vendor/libs/popper/popper.js"></script>
    <script src="<?php echo e(url('public')); ?>/assets/vendor/js/bootstrap.js"></script>
    <script src="<?php echo e(url('public')); ?>/assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.js"></script>

    <script src="<?php echo e(url('public')); ?>/assets/vendor/libs/hammer/hammer.js"></script>
    <script src="<?php echo e(url('public')); ?>/assets/vendor/libs/i18n/i18n.js"></script>
    <script src="<?php echo e(url('public')); ?>/assets/vendor/libs/typeahead-js/typeahead.js"></script>
    <script src="<?php echo e(url('public')); ?>/assets/vendor/libs/toastr/toastr.js"></script>

    <script src="<?php echo e(url('public')); ?>/assets/vendor/js/menu.js"></script>
    <!-- endbuild -->

    <!-- Vendors JS -->
    <script src="<?php echo e(url('public')); ?>/assets/vendor/libs/formvalidation/dist/js/FormValidation.min.js"></script>
    <script src="<?php echo e(url('public')); ?>/assets/vendor/libs/formvalidation/dist/js/plugins/Bootstrap5.min.js"></script>
    <script src="<?php echo e(url('public')); ?>/assets/vendor/libs/formvalidation/dist/js/plugins/AutoFocus.min.js"></script>

    <!-- Main JS -->
    <script src="<?php echo e(url('public')); ?>/assets/js/main.js"></script>

    <!-- Page JS -->
    <script src="<?php echo e(url('public')); ?>/assets/js/pages-auth.js"></script>

    <script src="<?php echo e(url('public')); ?>/assets/js/ui-toasts.js"></script>

    <script>
        const toastPlacementExample = document.querySelector('.toast-placement-ex');
        const toastPlacementExampleS = document.querySelector('.toast-placement-success');
        let selectedType, selectedPlacement, toastPlacement, selectedTypeS, selectedPlacementS, toastPlacementS;


        selectedPlacement = ['top-0', 'end-0'];


        <?php if(Session::get('success')): ?>
        $('.success_custom_body').html("<?php echo e(session('success')); ?>");
        if (toastPlacementS) {
            toastPlacementS.dispose();
        }
        selectedTypeS = 'bg-success';
        toastPlacementExampleS.classList.add(selectedTypeS);
        DOMTokenList.prototype.add.apply(toastPlacementExampleS.classList, selectedPlacement);
        toastPlacementS = new bootstrap.Toast(toastPlacementExampleS);
        toastPlacementS.show();
        <?php Session::put('success', '');
        ?>
        <?php endif; ?>

        <?php if(Session::get('error')): ?>
        $('.error_custom_body').html("<?php echo e(session('error')); ?>");
        if (toastPlacement) {
            toastPlacement.dispose();
        }
        selectedType = 'bg-danger';
        toastPlacementExample.classList.add(selectedType);
        DOMTokenList.prototype.add.apply(toastPlacementExample.classList, selectedPlacement);
        toastPlacement = new bootstrap.Toast(toastPlacementExample);
        toastPlacement.show();
        <?php Session::put('error', '');
        ?>
        <?php endif; ?>
    </script>
</body>

</html><?php /**PATH C:\xampp\htdocs\bloomli\resources\views/layout/auth.blade.php ENDPATH**/ ?>