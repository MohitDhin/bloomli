<!-- saved from url=(0055)file:///C:/Users/naviukswt/Downloads/invoice-three.HTML -->
<html>

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
</head>

<body>
    <table cellpadding="0" cellspacing="0" style="width: 100%; max-width: 600px; margin: 0 auto; display: table;font-family: &#39;arial&#39;; box-shadow: 0 0 10px 1px #ddd; padding: 20px;background-image: url(img/cr.png);
    background-repeat: no-repeat;
    background-position: center;">
        <tbody>
            <tr>
                <td style="text-align: center;"><img style="max-width:100px;" src="{{url('public')}}/assets/img/branding/logo.png"></td>
            </tr>

            <tr>
                <td style="padding-top: 20px;padding-bottom: 8px;text-align: left;color: #8c8c8c;font-weight: 300;
    line-height: 24px;">Verify Your Email Address</td>
            </tr>
            <tr>
                <td style="padding-top: 20px;padding-bottom: 8px;text-align: center;color: #8c8c8c;font-weight: 300;
    line-height: 24px;"><a href="{{url('reset-password')}}/{{$token}}" style="background: #d13539;border: 0;color: #fff;padding: 13px 30px;font-size: 17px;
    border-radius: 4px;">Click Here</a> </td>
            </tr>
            <!-- <tr>
                <td style="padding-top: 20px;padding-bottom: 8px;text-align: left;color: #8c8c8c;font-weight: 300;
    line-height: 24px;">Lorem Ipsum is simply dummy text of the printing and typesetting industry. </td>
            </tr> -->
            <!-- <tr>
                <td colspan="2" style="padding-bottom: 8px;padding-top: 10px;"><b>To Test Team</b></td>
            </tr> -->

        </tbody>
    </table>
</body>

</html>