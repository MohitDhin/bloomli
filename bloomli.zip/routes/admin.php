<?php
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AdminController;

/*
|--------------------------------------------------------------------------
| Admin Routes
|--------------------------------------------------------------------------
|
| Here is where you can register admin routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "admin" middleware group. Now create something great!
|
*/


Route::any('/',[AdminController::class, "index"]);
Route::any('login',[AdminController::class, "login"]);
Route::any('forgot-password',[AdminController::class, "forgotpassword"])->name('admin.forgot.password');
Route::any('reset-password/{token}',[AdminController::class, "resetPassword"])->name('admin.reset.password');
Route::any('update-password',[AdminController::class, "updatePassword"])->name('admin.update.password');
Route::any('logout',[AdminController::class, "logout"]);